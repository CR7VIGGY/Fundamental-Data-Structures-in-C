#include<iostream>
using namespace std;
#include<conio.h>
#include<stdio.h>
#include<string.h>

void display(int a);
void enter();

//program a structure for ten students ......
    struct addr
	{
		int hn;
		char area[26];
		char city[26];
		char state[26];
    };
    
    struct stud
    {
    	int id;
    	char name[26];
    	char branch[26];
    	addr address;
    	float marks;
    	
	}student,s[2];
	
	
	int main()
	{
		int i , sno , flag = 0;
		char ch ;
		enter();
		do
		{
			cout<<"enter student id no. who's details is to be displayed \n";
			cin>>sno;
			
			for(i = 0 ; i < 2 ; i++)
			{
				if(s[i].id == sno)
				{
					display(i);
					flag = 1;
					break;
				}
			}
			if(!flag)
			{
				cout<<"sorry no such student  exists";
			}
			cout<<"display more y/n";
			cin>>ch;
					
		}
		while(ch == 'y');
		return 0;
	}
	
	void enter(void)                                                     //enter details
	{
		for(int i = 0 ; i < 2 ; i++)
		{
			cout<<"enter student id no.";
			cin>>s[i].id;
			cout<<"enter name";
			gets(s[i].name);
			cout<<"enter branch";
			gets(s[i].branch);
			cout<<"enter address\n";
			cout<<"enter house no.";
			cin>>s[i].address.hn;
			cout<<"enter area";
			gets(s[i].address.area);
			cout<<"enter city";
			gets(s[i].address.city);
			cout<<"enter state";
			gets(s[i].address.state);
			cout<<"enter marks";
			cin>>s[i].marks;
			cout<<"\n";
			
		}
		return ;
	}
	
	void display(int a)
	{
		cout<<"STUDENT DATA";
		cout<<"\n"<<"student id no."<<s[a].id<<"\n";
		cout<<"name";
		puts(s[a].name);
		cout<<"\n";
		cout<<"branch";
		puts(s[a].branch);
		cout<<"\n";
		cout<<"address"<<"\n";
		cout<<s[a].address.hn;
		puts(s[a].address.area);
		puts(s[a].address.city);
		puts(s[a].address.state);
		cout<<"\n";
		cout<<"marks";
		cout<<s[a].marks;
		cout<<"\n";
		
		return ;
	}
	
	
	
	
										
										
										
										
    
    
	


