#include<bits/stdc++.h>
using namespace std;

void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
 
int breaknrule (int x[], int low, int high)
{
    int pvt = x[high]; 
    int i = (low - 1);  
 
    for (int j = low; j <= high- 1; j++)
    {
      
        if (x[j] <= pvt)
        {
            i++;    
            swap(&x[i], &x[j]);
        }
    }
    swap(&x[i + 1], &x[high]);
    return (i + 1);
}
 

void Sort(int x[], int low, int high)
{
    if (high > low)
    {
        
        int p = breaknrule(x, low, high);
 		//recursion
        Sort(x, low, p - 1);
        Sort(x, p + 1, high);
    }
}

int main()
{
	int a;
	scanf("%d",&a);
    int x[a];
    for(int i = 0 ; i < a ; i++)
    scanf("%d",&x[i]);
    
    Sort(x, 0, a-1);//calling function
    
    printf("SORTED ARRAY IS:");
   
    	for (int i=0; i < a; i++)
        printf("%d ", x[i]);
    	printf("\n");
    	
    	return 0;
}
