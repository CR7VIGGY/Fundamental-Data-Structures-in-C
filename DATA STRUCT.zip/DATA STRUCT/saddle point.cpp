#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,i,j,k,m= 0;
	cin>>n;
	int x[n][n];
	int y[m];
	for(int i = 0 ; i < n ; i++)
	for(int j = 0 ; j < n ; j++)
	cin>>x[i][j];
	
	
	
	for(i = 0 ; i < n ; i++)
	{
		for(j = 0 ; j < n ; j++)
		{
			if(x[i][j]<x[i][j+1])
			{
				for(k = 0 ; k < n ; k++)
				{
					if(x[i][j] > x[k][j] )
					cout<<x[i][j];
				}
			}
		}
	}

}
