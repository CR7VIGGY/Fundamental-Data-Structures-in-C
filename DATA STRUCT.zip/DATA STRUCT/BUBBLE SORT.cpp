//bubble sort
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i,j,temp= 0 ,a;
	cin>>a;
	int x[a];
	for(i = 0 ; i < a ; i++)
	{
		cin>>x[i];
	}
	
	for (i = 0; i < a-1; i++)      
 
       // Last i elements are already in place   
       for (j = 0; j < a-i-1; j++) 
           if (x[j] > x[j+1])
            swap(x[j], x[j+1]);

	for(i = 0 ; i < a ; i++)
	{
		cout<<" "<<x[i];
	}
	return 0;
}
