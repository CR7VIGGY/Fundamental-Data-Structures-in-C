//insertion sort
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i,j,temp= 0 ,a;
	cin>>a;
	int x[a];
	for(i = 0 ; i < a ; i++)
	{
		cin>>x[i];
	}
	for(i = 1 ; i <a; i++)
	{
		temp = x[i];
		for(j = i-1 ; j >=0 && temp < x[j] ;)
		{
			x[j+1] = x[j];
			j--;
		}
		x[j+1] = temp;
	}
	
	for(i = 0 ; i < a ; i++)
	{
		cout<<x[i]<<" ";
	}
	return 0;
}
