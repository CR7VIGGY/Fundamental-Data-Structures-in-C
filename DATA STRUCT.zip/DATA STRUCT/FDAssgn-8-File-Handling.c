//ASSIGNMENT - 6
#include<stdio.h>
typedef struct Student
{
    int roll;
    char name[50];
    char branch[50];
    float marks;
}Student;

FILE *ptr,*pt;

void insert()
{
    Student s1;
    fseek(ptr,0,2);

    printf("Enter Roll_No : ");
    scanf("%d",&s1.roll);
     printf("Enter the Name : ");
    scanf("%s",s1.name);
     printf("Enter Your Branch : ");
    scanf("%s",s1.branch);
     printf("Enter your Marks : ");
    scanf("%f",&s1.marks);

    fprintf(ptr,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);

}


void search()
{
        Student s1;
        int roll;
        printf("Enter the roll no to be searched : ");
        scanf("%d",&roll);
        //fopen("");
        fopen(ptr,"w+");
        rewind(ptr);
        while(feof(ptr)==0)
        {
            fscanf(ptr,"%d%s%s%f",&s1.roll,s1.name,s1.branch,&s1.marks);
            if(s1.roll==roll)
            {
                            printf("\nRoll.No Name    Branch   Marks\n");
                            printf("%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
                            return ;
            }
        }
        printf("Invalid Roll_Number\n");
}

void mod()
{
        Student s1;
        int roll;
        printf("Enter the roll no to be searched : ");
        scanf("%d",&roll);
        //fopen("");
        fopen(ptr,"w+");
        rewind(ptr);
        while(feof(ptr)==0)
        {
            fscanf(ptr,"%d%s%s%f",&s1.roll,s1.name,s1.branch,&s1.marks);
            if(s1.roll==roll)
            {
                            printf("\nRoll.No Name    Branch   Marks\n");
                            printf("%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
                            return ;
            }
        }
        printf("Invalid Roll_Number\n");
}

void modify()
{
        Student s1;
        int rol;
        int ro;
        printf("Enter the Record No to be modified : ");
        scanf("%d",&rol);
        pt = fopen("pt.txt","w+");
        rewind(ptr);
        int i;
        printf("Roll.No Name    Branch   Marks\n");
        for(i=0;i<rol&& !feof(ptr);i++)
        {
            fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);

            fprintf(pt,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
        }
        if(feof(ptr))
        {
            printf("Record is Out of Range");
        }
        else
        {
            fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);
            printf("\nEnter new Roll_No,name,branch,marks :\n");

            scanf("%d%s%s%f",&ro,s1.name,s1.branch,&s1.marks);

            fprintf(pt,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
            while(feof(ptr)==0)
            {
                fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);
                fprintf(pt,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
            }
            fclose(ptr);
            fclose(pt);
            ptr = fopen("Filedatabse.txt","w+");
            pt = fopen("pt.txt","r+");
            while(feof(pt)==0)
            {
                fscanf(pt,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);
                fprintf(ptr,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
            }
        }
}

void display()
{
    Student s1;

    rewind(ptr);
    while(!feof(ptr))
    {
        fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);
        printf("\n%d\t%s\t%s\t%f",s1.roll,s1.name,s1.branch,s1.marks);
    }

}

void del()
{
     Student s1;
        int rol;
        printf("Enter the Record No to be deleted: ");
        scanf("%d",&rol);
        pt = fopen("pt.txt","w+");
        rewind(ptr);
        int i;

        for(i=0;i<rol&& !feof(ptr);i++)
        {
            fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);

            fprintf(pt,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
        }
        if(feof(ptr))
        {
            printf("Record is Out of Range");
        }
        else
        {
            fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);

            while(feof(ptr)==0)
            {
                fscanf(ptr,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);
                fprintf(pt,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
            }
            fclose(ptr);
            fclose(pt);
            ptr = fopen("Filedatabse.txt","w+");
            pt = fopen("pt.txt","r+");
            while(feof(pt)==0)
            {
                fscanf(pt,"%d%s%s%f\n",&s1.roll,s1.name,s1.branch,&s1.marks);
                fprintf(ptr,"%d\t%s\t%s\t%f\n",s1.roll,s1.name,s1.branch,s1.marks);
            }
        }

}




int main()
{
    Student s1;
    char str[50];
    int x,i,j,k;
    ptr = fopen("Vighnesh.txt","r+");
    if(ptr == NULL)
    {
        ptr = fopen("Vighnesh.txt","w+");
    }

    do
    {
        printf("\nEnter Your Choice :\n1.Insert\n2.Modify\n3.Delete\n4.Search\n5.Display\n6.Exit\n ");
        scanf("%d",&k);
        switch(k)
        {
            case 1: insert();
            break;
            case 2: modify();
            break;
            case 3: del();
            break;
            case 4: search();
            break;
            case 5: printf("Roll.No Name    Branch   Marks\n");
                    display();
                    break;
            case 6: return 0;
        }

    }while(k<7);


}
