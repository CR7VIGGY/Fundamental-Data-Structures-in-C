#include<bits/stdc++.h>
using namespace std;
int fun(int*);
int main()
{
	int x = 10;
	int *p;
	fun(&x);
	
}
int fun(int*p)
{
	
	cout<<p;
	return 0;
}
