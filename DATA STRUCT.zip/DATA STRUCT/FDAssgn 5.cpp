//assgn no. 5 bubble sort in ascending order and insertion sort in descending order
#include<stdio.h>
#include<string.h>
void bubble(char x[],int a);
void insertion(char x[],int a);
void binary(char x[],int a);
int main()
{
	int a,b,c,i,j,k,m;
	printf("ENTER THE SIZE OF YOUR STRING \n");
	scanf("%d",&a);
	char x[a];
	printf("ENTER THE ELEMENTS IN THE STRING\n");
	for(i = 0 ; i <= a ; i++)
	{
		scanf("%c",&x[i]);
	}
	
	do
	{
		printf("PRESS 1: APPLY BUBBLE SORT\nPRESS 2: APPLY INSERTION SORT\nPRESS 3 TO USE BINARY SEARCH\nPRESS 4 : EXIT\n ");
		scanf("%d",&m);
		switch(m)
		{
			case 1 : bubble(x,a);break;
			case 2 : insertion(x,a);break;
			case 3 : binary(x,a);break;
			case 4 : break;
		}
	}
	while(m!=4);
	return 0;
	
}
void bubble(char x[],int a)
{
	int i,j,k,temp = 0;
	for(i = 0 ; i <= a ; i++)
	{
		for(j = i+1 ; j <= a; j++)
		{
			if(x[i] > x[j])
			{
				temp = x[i];
				x[i] = x[j];
				x[j] = temp;
			}
		}
	}
	printf("SORTED ARRAY IS : \n");
	for(i = 0 ; i <= a ; i++)
	{
		printf("%c ",x[i]);
	}
	printf("\n");
}

void insertion(char x[],int a)
{
	int i,j,k,temp=0;
	for(i = 1 ; i <= a ; i++)
	{
		temp = x[i];
		j = i-1;
		while(j>=0 && temp > x[j])
		{
			x[j+1] = x[j];
			j--;
		}
		x[j+1] = temp;	
	}
	
	printf("SORTED ARRAY IS :");
	for(i = 0 ; i <= a ; i++)
	{
		printf("%c ",x[i]);
	}
	printf("\n");
	
}
void binary(char x[],int a)
{
	int i,j,k,temp = 0;
	char search;
	//sorted array only
	int start,end;
	//using bubble sort
	for(i = 0 ; i < a ; i++)
	{
		for(j = i+1 ; j < a; j++)
		{
			if(x[i] > x[j])
			{
				temp = x[i];
				x[i] = x[j];
				x[j] = temp;
			}
		}
	}
	/*printf("SORTED ARRAY IS : \n");
	for(i = 0 ; i <= a ; i++)
	{
		printf("%c ",x[i]);
	}
	printf("\n");*/
	//binary search
	start = 0;
	end = a-1;
	int mid = (start+end)/2;
	
	printf("enter the char to be searched\n");
	scanf("%s",&search);
	
	while(start <= end)
	{
		if(x[mid] < search)
		{
			start = mid+1;
			mid = (start+end)/2;
		}
		else if(x[mid] == search)
		{
			printf("%cfound at %d\n",search,mid);break;
		}
		else
		{
			end = mid-1;
			mid = (start+end)/2;
		}
	}
	
	if(start > end)
	{
		printf("\n %c not found in array\n");
	}
	
}
