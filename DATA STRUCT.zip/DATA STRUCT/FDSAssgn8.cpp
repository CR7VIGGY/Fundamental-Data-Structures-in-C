#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,i,j,k,c,d;
	printf("enter the row and column of matrix A");
	scanf("%d %d",&a,&b);
	printf("enter row column of matrix B");
	scanf("%d %d",&c,&d);
	
	int x[a][b],y[c][d];
	printf("\nenter matrix A\n");
	for(i = 0 ; i < a ; i++)
	{
		for(j = 0 ; j < b ; j++)
		{
			scanf("%d",&x[i][j]);
		}
	}
	printf("\nenter matrix B\n");
	for(i = 0 ; i < c ; i++)
	{
		for(j = 0 ; j < d ; j++)
		{
			scanf("%d",&y[i][j]);
		}
	}
	int non=0,zero,count = 0;
	
	printf("\nrow\tcolumn\tnonzero");
	
	for(i = 0 ; i < a ; i++)
	{
		for(j = 0 ; j < b ; j++)
		{
			if(x[i][j]!=0)
			{
				non++;
			}
				
		}
	}
	//for matrix 2nd
	int non1=0,l;
	for(i = 0 ; i < c ; i++)
	{
		for(j = 0 ; j < d ; j++)
		{
			if(y[i][j]!=0)
			{
				non1++;
			}
				
		}
	}
	
	printf("\n%d\t %d\t %d",a,b,non);
	
	for(i = 0 ; i < a ; i++)
	{
		for(j = 0 ; j < b ; j++)
		{
			if(x[i][j]!=0)
			{
				printf("\n%d\t %d\t %d",i,j,x[i][j]);
			}
				
		}
	}
	
	//o/p2nd matrix
	printf("\nrow\tcolumn\tnonzero");
	
	printf("\n%d\t %d\t %d",c,d,non1);
	
	for(i = 0 ; i < a ; i++)
	{
		for(j = 0 ; j < b ; j++)
		{
			if(y[i][j]!=0)
			{
				printf("\n%d\t %d\t %d",i,j,y[i][j]);
			}
				
		}
	}
	printf("\n");
	printf("\naddition of sparse matrix A and B:\n");
	
	if(a==c && b==d)
	{
	
		printf("\nrow\tcolumn\tnonzero");
		
		printf("\n%d\t %d\t %d",c,d,non+non1);
		
		for(i = 0,k = 0 ; i < a, k< c ; i++,k++)
		{
			for(j = 0,l = 0 ; j < b, l < d ; j++,l++)
			{
				if(y[k][l]!=0||x[i][j]!=0)
				{
					printf("\n%d\t %d\t %d",i,j,x[i][j]+y[k][l]);
				}
				
			}
		}
	}
	else
	{
		printf("addition not possible");
	}
	//multiplication
	printf("\n");
	printf("\nmultiplication of sparse matrix A and B:\n");
	
	if(b == c)
	{
	
		printf("\nrow\tcolumn\tnonzero");
		
		printf("\n%d\t %d\t %d",c,d,non+non1);
		
		for(i = 0,k = 0 ; i < a, k< c ; i++,k++)
		{
			for(j = 0,l = 0 ; j < b, l < d ; j++,l++)
			{
				if(y[k][l]!=0||x[i][j]!=0)
				{
					printf("\n%d\t %d\t %d",i,j,x[i][j]*y[k][l]);
				}
				
			}
		}
	}
	else
	{
		printf("addition not possible");
	}
	
	return 0;
}


