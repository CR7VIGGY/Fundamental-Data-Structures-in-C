#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i,j,k,first,last,mid,search;
	int a;
	cout<<"enter size of array";
	cin>>a;
	int x[a];
	cout<<"enter array elements";
	for(i = 0 ; i < a ; i++)
	{
		cin>>x[i];
	}
	first = 0 ;
	last = a-1;
	mid = (first+last)/2;
	cout<<"enter the element to be searched";
	cin>>search;
	while(first <= last)
	{
		if(x[mid] < search)
		{
			first = mid+1;
			mid = (first+last)/2;
		}
		else if(x[mid] == search)
		{
			cout<<"found"<<search<<"at"<<mid+1;
			break;
		}
		else
		{
			last = mid-1;
			mid = (first+last)/2;
			
		}
	}
	if(first > last)
	{
		cout<<"NOT FOUND";
	}
	return 0;
}
